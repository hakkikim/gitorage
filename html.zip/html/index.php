

<?php
$string =  '<!DOCTYPE html>'.
'<html lang="en">'.
'<head>'.
'<meta charset="utf-8">'.
'   <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">'.
'   <meta name="description" content="Park JIHO and KIM HAKKI\'s Portpolio page">'.
'   <meta name="author" content="Devcrud">'.
'   <title>Park&KIM\'s Portpolio page</title>'.
'   <!-- font icons -->'.
'   <link rel="stylesheet" href="assets/vendors/themify-icons/css/themify-icons.css">'.
'   <!-- Bootstrap + LeadMark main styles -->'.
'<link rel="stylesheet" href="assets/css/leadmark.css">'.
'</head>'.
'<body data-spy="scroll" data-target=".navbar" data-offset="40" id="home">'.
'    <!-- page Navigation -->'.
'   <nav class="navbar custom-navbar navbar-expand-md navbar-light fixed-top" data-spy="affix" data-offset-top="10">'.
'       <div class="container">'.
'           <a class="navbar-brand" href="#">'.
'               <img src="assets/imgs/logo.gif" alt="">'.
'           </a>'.
'           <button class="navbar-toggler ml-auto" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">'.
'               <span class="navbar-toggler-icon"></span>'.
'           </button>'.
'           <div class="collapse navbar-collapse" id="navbarSupportedContent">'.
'               <ul class="navbar-nav ml-auto">                     '.
'                   <li class="nav-item">'.
'                       <a class="nav-link" href="#service">Programs</a>'.
'                   </li>'.
'                   <li class="nav-item">'.
'                       <a class="nav-link" href="#portfolio">Tools</a>'.
'                   </li>'.
'                   <li class="nav-item">'.
'                       <a class="nav-link" href="#Participants">Participants</a>'.
'                   </li>'.
'                   <li class="nav-item">'.
'                       <a class="nav-link" href="#blog">Articles</a>'.
'                   </li>'.
'		<li class="nav-item">'.
'                       <a class="nav-link" href="#Venue">Venue</a>'.
'                   </li>'.
'                   <li class="nav-item">'.
'                       <a class="nav-link" href="#contact">Contact</a>'.
'                   </li>'.
'	    <li class="nav-item">'.
'		<a href="download.html" class="ml-4 nav-link btn btn-primary btn-sm rounded">Download</a>'.
'		</p>'.
'	    </li>'.
'                </ul>'.
'           </div>'.
'       </div>'.
'   </nav>'.
'   <!-- End Of Second Navigation -->'.
'    <!-- Page Header -->'.
'   <header class="header">'.
'       <div class="overlay">'.
'           <h1 class="subtitle">K-Digital Hybrid and Multicloud Architect</h1>'.
'           <h1 class="title">Park Jiho & Kim Hakki</h1>'.
'           <h1 class="subtitle">2023.4.25 AM 10:00 GMT +9</h1>  '.
'           <h1 class="subtitle">KGITBANK Jongro 508</h1>'.
'       </div>  '.
'       <div class="shape">'.
'           <svg viewBox="0 0 1500 200">'.
'               <path d="m 0,240 h 1500.4828 v -71.92164 c 0,0 -286.2763,-81.79324 -743.19024,-81.79324 C 300.37862,86.28512 0,168.07836 0,168.07836 Z"/>'.
'           </svg>'.
'       </div>  '.
'       <div class="mouse-icon"><div class="wheel"></div></div>'.
'   </header>'.
'   <!-- End Of Page Header -->'.
'    <!-- Service Section -->'.
'   <section  id="service" class="section pt-0">'.
'       <div class="container">'.
'           <h6 class="section-title text-center">Programs</h6>'.
'           <h6 class="section-subtitle text-center mb-5 pb-3">포트폴리오 발표 내용</h6>'.
'            <div class="row">'.
'               <div class="col-md-3">'.
'                   <div class="card mb-4 mb-md-0">'.
'                       <div class="card-body">'.
'                           <small class="text-primary font-weight-bold">01</small>'.
'                           <h5 class="card-title mt-3"> Infra <h5>'.
'                           <p class="mb-0"> 한정된 온프레미스 자원을 최대한 활용한 사설네트워크망. vCenter를 이용, 호스트 및 가상머신 관리, AD를 사용한 DHCP/DNS 설정으로 관리 편의성 증대. HA Cluster 및 DRS를 이용 동적 자원할당 및 자동 장애복구 </p>'.
'                       </div>'.
'                   </div>'.
'               </div>'.
'               <div class="col-md-3">'.
'                   <div class="card mb-4 mb-md-0">'.
'                       <div class="card-body">'.
'                           <small class="text-primary font-weight-bold">02</small>'.
'                           <h5 class="card-title mt-3">Web<h5>'.
'                           <p class="mb-0">  메인 서버에 구성된 Tomcat에 Amazon S3와 Google Cloud Storage 연동.'.
'라이브 마이그레이션이 가능한 WEB&WAS-DB 구성.'.
'인증코드 미입력시 DB에 저장을 하지 못하도록 설정.'.
'접속환경에 따라 변하는 반응형 웹페이지.</p>'.
'                       </div>'.
'                   </div>'.
'               </div>'.
'               <div class="col-md-3">'.
'                   <div class="card mb-4 mb-md-0">'.
'                       <div class="card-body">'.
'                           <small class="text-primary font-weight-bold">03</small>'.
'                           <h5 class="card-title mt-3">IaC<h5>'.
'                           <p class="mb-0"> 관리 편의 및 테스트 목적의 코드형 인프라. 테라폼을 이용한 VM 제어와 앤서블을 이용한 AWS 인스턴스 관리. 쉘스크립트와 쿠버네티스를 사용, 도커 등의 컨테이너형 서비스 관리시스템 제어</p>'.
'                       </div>'.
'                   </div>'.
'               </div>'.
'               <div class="col-md-3">'.
'                   <div class="card mb-4 mb-md-0">'.
'                       <div class="card-body">'.
'                           <small class="text-primary font-weight-bold">04</small>'.
'                           <h5 class="card-title mt-3">Multi & Hybrid Cloud<h5>'.
'                           <p class="mb-0"> NAT-GW를 통한 공용망 접근. AWS Lambda와 Eventbridge, Telegram을 이용해 FinOps지원 - 일일 사용량 알람 등 </p>'.
'                       </div>'.
'                   </div>'.
'               </div>'.
'           </div>'.
'       </div>'.
'   </section>'.
'   <!-- End OF Service Section -->'.
'    <!-- '.
'   <section class="section" id="about">'.
'       <div class="container">'.
'           <div class="row justify-content-between">'.
'               <div class="col-md-6 pr-md-5 mb-4 mb-md-0">'.
'                   <h6 class="section-title mb-0">About Company</h6>'.
'                   <h6 class="section-subtitle mb-4">Architecto provident deserunt</h6>'.
'                   <p >Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptate molestiae temporibus et tenetur unde quasi, cum nemo quo, molestias architecto alias voluptatibus corrupti corporis earum. Necessitatibus maxime modi ipsam, quod!</p>'.
'                   <img src="assets/imgs/about.jpg" alt="" class="w-100 mt-3 shadow-sm">'.
'               </div>'.
'               <div class="col-md-6 pl-md-5">'.
'                   <div class="row">'.
'                       <div class="col-6">'.
'                           <img src="assets/imgs/about-1.jpg" alt="" class="w-100 shadow-sm">'.
'                       </div>'.
'                       <div class="col-6">'.
'                           <img src="assets/imgs/about-2.jpg" alt="" class="w-100 shadow-sm">'.
'                       </div>'.
'                       <div class="col-12 mt-4">'.
'                           <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nemo iusto quidem laborum atque, sapiente ipsa excepturi fuga cum sed in assumenda eos quasi harum culpa laboriosam nulla, incidunt quae. Voluptatum.</p>'.
'                           <p><b>Aliquid fuga sunt velit, temporibus molestias ab. Ipsa nesciunt totam, aliquid dignissimos.</b><br>'.
'                           </p>'.
'                           <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nesciunt ut a dolorem, consectetur, eos suscipit consequatur magnam est dolore obcaecati adipisci expedita, vero, iste ducimus qui numquam animi facilis officia?</p>'.
'                       </div>'.
'                   </div>'.
'               </div>'.
'           </div>              '.
'       </div>'.
'   </section>'.
'   --!>'.
'    <!-- Portfolio Section -->'.
'   <section id="portfolio" class="section portfolio-section">'.
'       <div class="container">'.
'           <h6 class="section-title text-center">Tools</h6>'.
'           <h6 class="section-subtitle mb-5 text-center"> What we use in our project</h6>'.
'           <h6 class="section-subtitle mb-5 text-center"> VM / OS / Service / Language / Compiler / ETC</h6>'.
'           <div class="filters">'.
'               <a href="#" data-filter=".infra" class="active">'.
'                   Infra'.
'               </a>'.
'               <a href="#" data-filter=".web">'.
'                   Web'.
'               </a>'.
'               <a href="#" data-filter=".iac">'.
'                   IaC'.
'               </a>'.
'               <a href="#" data-filter=".cloud">'.
'	    Cloud'.
'	</a>'.
'           </div>'.
'           <div class="portfolio-container"> '.
'               <div class="col-md-6 col-lg-4 iac">'.
'                   <div class="portfolio-item">'.
'		<div style="text-align : center;">'.
'                       <img src="assets/imgs/iac-1.png" class="img-fluid" alt="Download free bootstrap 4 admin dashboard, free boootstrap 4 templates">'.
'                       <div class="content-holder">'.
'                           <a class="img-popup" href="assets/imgs/iac-1.png"></a>'.
'                           <div class="text-holder">'.
'                               <h6 class="title">Terraform</h6>'.
'                               <p class="subtitle">코드형 인프라스트럭처, HCL이라는 선언형 구성 언어나 JSON을 사용</p>'.
'                           </div>'.
'                       </div>'.
'		</div>   '.
'                   </div>             '.
'               </div>'.
'               <div class="col-md-6 col-lg-4 iac all">'.
'                   <div class="portfolio-item">'.
'		<div style="text-align : center;">'.
'                       <img src="assets/imgs/iac-2.jpg" class="img-fluid" alt="Download free bootstrap 4 admin dashboard, free boootstrap 4 templates">'.
'                       <div class="content-holder">'.
'                           <a class="img-popup" href="assets/imgs/iac-2.jpg"></a>'.
'                           <div class="text-holder">'.
'                               <h6 class="title">Ansible</h6>'.
'                               <p class="subtitle">프로비저닝, 구성 관리, 애플리케이션 전개 도구</p>'.
'                           </div>'.
'		</div>'.
'                       </div> '.
'                   </div>                         '.
'               </div>'.
'               <div class="col-md-6 col-lg-4 iac all">'.
'                   <div class="portfolio-item">'.
'		<div style="text-align : center;">'.
'                       <img src="assets/imgs/iac-3.png" class="img-fluid" alt="Download free bootstrap 4 admin dashboard, free boootstrap 4 templates">'.
'                       <div class="content-holder">'.
'                           <a class="img-popup" href="assets/imgs/iac-3.png"></a>'.
'                           <div class="text-holder">'.
'                               <h6 class="title">Docker</h6>'.
'                               <p class="subtitle">프로세스 격리 기술을 사용, 응용 프로그램들을 컨테이너로 실행/관리</p>'.
'                           </div>'.
'                       </div>'.
'		</div>   '.
'                   </div>             '.
'               </div>'.
'               <div class="col-md-6 col-lg-4 iac all">'.
'                   <div class="portfolio-item">'.
'		<div style="text-align : center;">'.
'                       <img src="assets/imgs/iac-4.png" class="img-fluid" alt="Download free bootstrap 4 admin dashboard, free boootstrap 4 templates">'.
'                       <div class="content-holder">'.
'                           <a class="img-popup" href="assets/imgs/iac-4.png"></a>'.
'                           <div class="text-holder">'.
'                               <h6 class="title">k8s</h6>'.
'                               <p class="subtitle">컨테이너화된 애플리케이션 관리시스템</p>'.
'                           </div>'.
'                       </div>'.
'		</div> '.
'                   </div>                         '.
'               </div>'.
'               <div class="col-md-6 col-lg-4 iac">'.
'                   <div class="portfolio-item">'.
'		<div style="text-align : center;">'.
'                       <img src="assets/imgs/iac-5.jpg" class="img-fluid" alt="Download free bootstrap 4 admin dashboard, free boootstrap 4 templates">                         '.
'                       <div class="content-holder">'.
'                           <a class="img-popup" href="assets/imgs/iac-5.jpg"></a>'.
'                           <div class="text-holder">'.
'                               <h6 class="title">Pycharm</h6>'.
'                               <p class="subtitle">특히 파이썬 프로그래밍 언어에 특화된 컴퓨터 프로그래밍에 사용되는 통합 개발 환경</p>'.
'                           </div>'.
'                       </div>'.
'		</div>    '.
'                   </div>              '.
'               </div> '.
'               <div class="col-md-6 col-lg-4 iac">'.
'                   <div class="portfolio-item">'.
'		<div style="text-align : center;">'.
'                       <img src="assets/imgs/iac-6.png" class="img-fluid" alt="Download free bootstrap 4 admin dashboard, free boootstrap 4 templates">'.
'                       <div class="content-holder">'.
'                           <a class="img-popup" href="assets/imgs/iac-6.png"></a>'.
'                           <div class="text-holder">'.
'                               <h6 class="title">Anaconda</h6>'.
'                               <p class="subtitle">패키지 관리와 디플로이 단순화를 위한 프로그래밍 언어툴</p>'.
'                           </div>'.
'                       </div>'.
'		</div>'.
'                   </div>                                                     '.
'               </div>'.
'                <div class="col-md-6 col-lg-4 iac"> '.
'                   <div class="portfolio-item">'.
'		<div style="text-align : center;">'.
'                       <img src="assets/imgs/iac-7.png" class="img-fluid" alt="Download free bootstrap 4 admin dashboard, free boootstrap 4 templates">                               '.
'                       <div class="content-holder">'.
'                           <a class="img-popup" href="assets/imgs/iac-7.png"></a>'.
'                           <div class="text-holder">'.
'                               <h6 class="title">Ruby</h6>'.
'                               <p class="subtitle">이식성이 뛰어난 동적 객체 지향 스크립트 프로그래밍 언어</p>'.
'                           </div>'.
'                       </div>'.
'		</div>'.
'                   </div>                                                       '.
'               </div> '.
'               <div class="col-md-6 col-lg-4 infra all">'.
'                   <div class="portfolio-item">'.
'		<div style="text-align : center;">'.
'                       <img src="assets/imgs/infra-1.png" class="img-fluid" alt="Download free bootstrap 4 admin dashboard, free boootstrap 4 templates">  '.
'                       <div class="content-holder">'.
'                           <a class="img-popup" href="assets/imgs/infra-1.png"></a>'.
'                           <div class="text-holder">'.
'                               <h6 class="title">Window Server 2019</h6>'.
'                               <p class="subtitle">윈도우 10의 서버 버전</p>'.
'                           </div>'.
'                       </div>'.
'		</div>'.
'                   </div>                                                     '.
'               </div>'.
'               <div class="col-md-6 col-lg-4 infra">'.
'                   <div class="portfolio-item">'.
'		<div style="text-align : center;">'.
'                       <img src="assets/imgs/infra-2.jpg" class="img-fluid" alt="Download free bootstrap 4 admin dashboard, free boootstrap 4 templates">       '.
'                      <div class="content-holder">'.
'                           <a class="img-popup" href="assets/imgs/infra-2.jpg"></a>'.
'                           <div class="text-holder">'.
'                               <h6 class="title">Window 10 pro</h6>'.
'                               <p class="subtitle">MS WIndows 계열 OS</p>'.
'                           </div>'.
'                       </div>'.
'		</div>'.
'                   </div>                                                       '.
'               </div> '.
'               <div class="col-md-6 col-lg-4 infra all"> '.
'                   <div class="portfolio-item">'.
'		<div style="text-align : center;">'.
'                       <img src="assets/imgs/infra-3.png" class="img-fluid" alt="Download free bootstrap 4 admin dashboard, free boootstrap 4 templates">            '.
'                       <div class="content-holder">'.
'                           <a class="img-popup" href="assets/imgs/infra-3.png"></a>'.
'                           <div class="text-holder">'.
'                               <h6 class="title">vSphere</h6>'.
'                               <p class="subtitle">VM ware 제품군 중 DataCenter에 포함, 통합 클라우드 OS</p>'.
'                           </div>'.
'                       </div>'.
'		</div>'.
'                   </div>'.
'               </div> '.
'               <div class="col-md-6 col-lg-4 infra">'.
'                   <div class="portfolio-item">'.
'		<div style="text-align : center;">'.
'                       <img src="assets/imgs/infra-4.png" class="img-fluid" alt="Download free bootstrap 4 admin dashboard, free boootstrap 4 templates">                        '.
'                       <div class="content-holder">'.
'                           <a class="img-popup" href="assets/imgs/infra-4.png"></a>'.
'                           <div class="text-holder">'.
'                               <h6 class="title">ESXi</h6>'.
'                               <p class="subtitle">VM ware의 엔터프라이즈 계열 타입 1 Hypervisor</p>'.
'                           </div>'.
'                       </div>'.
'		</div> '.
'                   </div>'.
'               </div> '.
'               <div class="col-md-6 col-lg-4 infra all">'.
'                   <div class="portfolio-item">'.
'		<div style="text-align : center;">'.
'                       <img src="assets/imgs/infra-5.png" class="img-fluid" alt="Download free bootstrap 4 admin dashboard, free boootstrap 4 templates">  '.
'                       <div class="content-holder">'.
'                           <a class="img-popup" href="assets/imgs/infra-5.png"></a>'.
'                           <div class="text-holder">'.
'                               <h6 class="title">CentOS7</h6>'.
'                               <p class="subtitle">레드햇 계열 리눅스 운영체제</p>'.
'                           </div>'.
'                       </div>'.
'		</div>'.
'                   </div>                                                     '.
'               </div> '.
'               <div class="col-md-6 col-lg-4 infra all">'.
'                   <div class="portfolio-item">'.
'		<div style="text-align : center;">'.
'                       <img src="assets/imgs/infra-6.png" class="img-fluid" alt="Download free bootstrap 4 admin dashboard, free boootstrap 4 templates">   '.
'                       <div class="content-holder">'.
'                           <a class="img-popup" href="assets/imgs/infra-6.png"></a>'.
'                           <div class="text-holder">'.
'                               <h6 class="title">MySQL</h6>'.
'                               <p class="subtitle">가장 많이 쓰이는 RDBMS</p>'.
'                           </div>'.
'                       </div>'.
'		</div>'.
'                   </div>                                                    '.
'               </div> '.
'               <div class="col-md-6 col-lg-4 infra">'.
'                   <div class="portfolio-item">'.
'		<div style="text-align : center;">'.
'                       <img src="assets/imgs/infra-7.png" class="img-fluid" alt="Download free bootstrap 4 admin dashboard, free boootstrap 4 templates">                      '.
'                       <div class="content-holder">'.
'                           <a class="img-popup" href="assets/imgs/infra-7.png"></a>'.
'                           <div class="text-holder">'.
'                               <h6 class="title">Freenas</h6>'.
'                               <p class="subtitle">BSD계열, 유료버전인 TrueNAS의 전신</p>'.
'                           </div>'.
'                       </div>'.
'		</div>'.
'                   </div>                                                      '.
'               </div> '.
'               <div class="col-md-6 col-lg-4 web all">'.
'                   <div class="portfolio-item">'.
'		<div style="text-align : center;">'.
'                       <img src="assets/imgs/web-1.png" class="img-fluid" alt="Download free bootstrap 4 admin dashboard, free boootstrap 4 templates">          '.
'                       <div class="content-holder">'.
'                           <a class="img-popup" href="assets/imgs/web-1.png"></a>'.
'                           <div class="text-holder">'.
'                               <h6 class="title">Tomcat</h6>'.
'                               <p class="subtitle">아파치 재단의 컨테이너형 웹 어플리케이션 서버</p>'.
'                           </div>'.
'                       </div>'.
'		</div>'.
'                   </div>                                                   '.
'               </div>'.
'<div class="col-md-6 col-lg-4 web">'.
'                   <div class="portfolio-item">'.
'		<div style="text-align : center;">'.
'                       <img src="assets/imgs/web-2.png" class="img-fluid" alt="Download free bootstrap 4 admin dashboard, free boootstrap 4 templates">   '.
'                       <div class="content-holder">'.
'                           <a class="img-popup" href="assets/imgs/web-2.png"></a>'.
'                           <div class="text-holder">'.
'                               <h6 class="title">Apache</h6>'.
'                               <p class="subtitle">크로스 플랫폼 HTTP 웹 서버</p>'.
'                           </div>'.
'                       </div>'.
'		</div>'.
'                   </div>                                                    '.
'               </div> '.
'<div class="col-md-6 col-lg-4 web">'.
'                   <div class="portfolio-item">'.
'		<div style="text-align : center;">'.
'                       <img src="assets/imgs/web-3.png" class="img-fluid" alt="Download free bootstrap 4 admin dashboard, free boootstrap 4 templates">   '.
'                       <div class="content-holder">'.
'                           <a class="img-popup" href="assets/imgs/web-3.png"></a>'.
'                           <div class="text-holder">'.
'                               <h6 class="title">Nginx</h6>'.
'                               <p class="subtitle">아파치에 이어 2번째로 많이 쓰이는 웹 서버</p>'.
'                           </div>'.
'                       </div>'.
'		</div>'.
'                   </div>                                                    '.
'               </div> '.
'<div class="col-md-6 col-lg-4 web all">'.
'                   <div class="portfolio-item">'.
'		<div style="text-align : center;">'.
'                       <img src="assets/imgs/web-4.png" class="img-fluid" alt="Download free bootstrap 4 admin dashboard, free boootstrap 4 templates">   '.
'                       <div class="content-holder">'.
'                           <a class="img-popup" href="assets/imgs/web-4.png"></a>'.
'                           <div class="text-holder">'.
'                               <h6 class="title">JSP</h6>'.
'                               <p class="subtitle">HTML과 연동해서 쓰이는 서버 사이드 스크립트 언어</p>'.
'                           </div>'.
'                       </div>'.
'		</div>'.
'                   </div>                                                    '.
'               </div>'.
'<div class="col-md-6 col-lg-4 web all">'.
'                   <div class="portfolio-item">'.
'		<div style="text-align : center;">'.
'                       <img src="assets/imgs/web-5.jpg" class="img-fluid" alt="Download free bootstrap 4 admin dashboard, free boootstrap 4 templates">   '.
'                       <div class="content-holder">'.
'                           <a class="img-popup" href="assets/imgs/web-5.jpg"></a>'.
'                           <div class="text-holder">'.
'                               <h6 class="title">HTML</h6>'.
'                               <p class="subtitle">하이퍼 텍스트 마크업 언어, 웹페이지</p>'.
'                           </div>'.
'                       </div>'.
'		</div>'.
'                   </div>                                                    '.
'               </div>'.
'	<div class="col-md-6 col-lg-4 cloud">'.
'                   <div class="portfolio-item">'.
'		<div style="text-align : center;">'.
'                       <img src="assets/imgs/cloud-1.png" class="img-fluid" alt="Download free bootstrap 4 admin dashboard, free boootstrap 4 templates">   '.
'                       <div class="content-holder">'.
'                           <a class="img-popup" href="assets/imgs/cloud-1.png"></a>'.
'                           <div class="text-holder">'.
'                               <h6 class="title">LAMBDA</h6>'.
'                               <p class="subtitle">AWS의 사건 기반 서버리스 컴퓨팅 플랫폼</p>'.
'                           </div>'.
'                       </div>'.
'		</div>'.
'                   </div>                                                    '.
'               </div>'.
'	<div class="col-md-6 col-lg-4 cloud">'.
'                   <div class="portfolio-item">'.
'		<div style="text-align : center;">'.
'                       <img src="assets/imgs/cloud-2.png" class="img-fluid" alt="Download free bootstrap 4 admin dashboard, free boootstrap 4 templates">   '.
'                       <div class="content-holder">'.
'                           <a class="img-popup" href="assets/imgs/cloud-2.png"></a>'.
'                           <div class="text-holder">'.
'                               <h6 class="title">EC2</h6>'.
'                               <p class="subtitle">Amazon Elastic Computing Cloud, 컴퓨팅 자원 추상화를 위한 도구</p>'.
'                           </div>'.
'                       </div>'.
'		</div>'.
'                   </div>                                                    '.
'               </div>'.
'	<div class="col-md-6 col-lg-4 cloud">'.
'                   <div class="portfolio-item">'.
'		<div style="text-align : center;">'.
'                       <img src="assets/imgs/cloud-3.png" class="img-fluid" alt="Download free bootstrap 4 admin dashboard, free boootstrap 4 templates">   '.
'                       <div class="content-holder">'.
'                           <a class="img-popup" href="assets/imgs/cloud-3.png"></a>'.
'                           <div class="text-holder">'.
'                               <h6 class="title">Amazon S3</h6>'.
'                               <p class="subtitle">Simple Storage Service, 웹 스토리지 제공 서비스</p>'.
'                           </div>'.
'                       </div>'.
'		</div>'.
'                   </div>                                                    '.
'               </div>'.
'	<div class="col-md-6 col-lg-4 cloud">'.
'                   <div class="portfolio-item">'.
'		<div style="text-align : center;">'.
'                       <img src="assets/imgs/cloud-4.png" class="img-fluid" alt="Download free bootstrap 4 admin dashboard, free boootstrap 4 templates">   '.
'                       <div class="content-holder">'.
'                           <a class="img-popup" href="assets/imgs/cloud-4.png"></a>'.
'                           <div class="text-holder">'.
'                               <h6 class="title">GCE</h6>'.
'                               <p class="subtitle">Google Computing Engine, 구글의 클라우드 컴퓨팅 서비스</p>'.
'                           </div>'.
'                       </div>'.
'		</div>'.
'                   </div>                                                    '.
'               </div>'.
'	<div class="col-md-6 col-lg-4 cloud">'.
'                   <div class="portfolio-item">'.
'		<div style="text-align : center;">'.
'                       <img src="assets/imgs/cloud-6.png" class="img-fluid" alt="Download free bootstrap 4 admin dashboard, free boootstrap 4 templates">   '.
'                       <div class="content-holder">'.
'                           <a class="img-popup" href="assets/imgs/cloud-6.png"></a>'.
'                           <div class="text-holder">'.
'                               <h6 class="title">Telegram</h6>'.
'                               <p class="subtitle">비영리 클라우드 기반 인터넷 메신저</p>'.
'                           </div>'.
'                       </div>'.
'		</div>'.
'                   </div>                                                    '.
'               </div>'.
'	<div class="col-md-6 col-lg-4 cloud">'.
'                   <div class="portfolio-item">'.
'		<div style="text-align : center;">'.
'                       <img src="assets/imgs/cloud-7.png" class="img-fluid" alt="Download free bootstrap 4 admin dashboard, free boootstrap 4 templates">   '.
'                       <div class="content-holder">'.
'                           <a class="img-popup" href="assets/imgs/cloud-7.png"></a>'.
'                           <div class="text-holder">'.
'                               <h6 class="title">EventBridge</h6>'.
'                               <p class="subtitle">AWS서비스 데이터를 수집 및 해당 데이터 대상 라우팅 서버리스 이벤트 버스</p>'.
'                           </div>'.
'                       </div>'.
'		</div>'.
'                   </div>                                                    '.
'               </div>'.
''.
'	<div class="col-md-6 col-lg-4 cloud">'.
'                   <div class="portfolio-item">'.
'		<div style="text-align : center;">'.
'                       <img src="assets/imgs/cloud-5.png" class="img-fluid" alt="Download free bootstrap 4 admin dashboard, free boootstrap 4 templates">   '.
'                       <div class="content-holder">'.
'                           <a class="img-popup" href="assets/imgs/cloud-5.png"></a>'.
'                           <div class="text-holder">'.
'                               <h6 class="title">Google Cloud Storage</h6>'.
'                               <p class="subtitle">구글의 웹 스토리지 제공 서비스</p>'.
'                           </div>'.
'                       </div>'.
'		</div>'.
'                   </div>                                                    '.
'               </div>'.
' '.
''.
'<div class="col-md-6 col-lg-4 cloud">'.
'                   <div class="portfolio-item">'.
'		<div style="text-align : center;">'.
'                       <img src="assets/imgs/cloud-8.svg" class="img-fluid" alt="Download free bootstrap 4 admin dashboard, free boootstrap 4 templates">   '.
'                       <div class="content-holder">'.
'                           <a class="img-popup" href="assets/imgs/cloud-8.svg"></a>'.
'                           <div class="text-holder">'.
'                               <h6 class="title">Python</h6>'.
'                               <p class="subtitle">객체지향형 동적타이핑 범용 프로그래밍 언어</p>'.
'                           </div>'.
'                       </div>'.
'		</div>'.
'                   </div>                                                    '.
'               </div>'.
'            </div>   '.
'       </div>            '.
'   </section>'.
'   <!-- End of portfolio section -->'.
'    <!-- Testmonial Section -->'.
'   <section class="section" id="Participants">'.
'       <div class="container">'.
'           <h6 class="section-title text-center mb-0">Participants</h6>'.
'           <h6 class="section-subtitle mb-5 text-center">What Our Clients Says</h6>'.
'           <div class="row">'.
'               <div class="col-md-4 my-3 my-md-0">'.
'                   <div class="card">'.
'                       <div class="card-body">'.
'                           <div class="media align-items-center mb-3">'.
'                               <img class="mr-3" src="assets/imgs/avatar.jpg" alt="">'.
'                               <div class="media-body">'.
'                                   <h6 class="mt-1 mb-0">John Doe</h6>'.
'                                   <small class="text-muted mb-0">Business Analyst</small>     '.
'                               </div>'.
'                           </div>'.
'                           <p class="mb-0">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Delectus enim modi, id dicta reiciendis itaque.</p>'.
'                       </div>'.
'                   </div>'.
'               </div>'.
'               <div class="col-md-4 my-3 my-md-0">'.
'                   <div class="card">'.
'                       <div class="card-body">'.
'                           <div class="media align-items-center mb-3">'.
'                               <img class="mr-3" src="assets/imgs/avatar-1.jpg" alt="">'.
'                               <div class="media-body">'.
'                                   <h6 class="mt-1 mb-0">Maria Garcia</h6>'.
'                                   <small class="text-muted mb-0">Insurance Agent</small>      '.
'                               </div>'.
'                           </div>'.
'                           <p class="mb-0">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Delectus enim modi, id dicta reiciendis itaque.</p>'.
'                       </div>'.
'                   </div>'.
'               </div>'.
'               <div class="col-md-4 my-3 my-md-0">'.
'                   <div class="card">'.
'                       <div class="card-body">'.
'                           <div class="media align-items-center mb-3">'.
'                               <img class="mr-3" src="assets/imgs/avatar-2.jpg" alt="">'.
'                               <div class="media-body">'.
'                                   <h6 class="mt-1 mb-0">Mason Miller</h6>'.
'                                   <small class="text-muted mb-0">Residential Appraiser</small>        '.
'                               </div>'.
'                           </div>'.
'                           <p class="mb-0">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Delectus enim modi, id dicta reiciendis itaque.</p>'.
'                       </div>'.
'                   </div>'.
'               </div>'.
'           </div>'.
'       </div>'.
'   </section>'.
'   <!-- End of Testmonial Section -->'.
'    <!-- Blog Section -->'.
'   <section class="section" id="blog">'.
'       <div class="container">'.
'           <h6 class="section-title mb-0 text-center">Latest Articles</h6>'.
'           <h6 class="section-subtitle mb-5 text-center">Architecto provident deserunt eveniet libero</h6>'.
'            <div class="row">'.
'               <div class="col-md-4">'.
'                   <div class="card border-0 mb-4">'.
'                       <img src="assets/imgs/blog-1.jpg" alt="" class="card-img-top w-100">'.
'                       <div class="card-body">                         '.
'                           <h6 class="card-title">Pariatur Omnis Harum quae sint.</h6>'.
'                           <p>Fuga quae ratione inventore Perferendis porro.</p>'.
'                           <a href="javascript:void(0)" class="small text-muted">Go To The Article</a>'.
'                       </div>'.
'                   </div>'.
'               </div>'.
'               <div class="col-md-4">'.
'                   <div class="card border-0 mb-4">'.
'                       <img src="assets/imgs/blog-2.jpg" alt="" class="card-img-top w-100">'.
'                       <div class="card-body">                         '.
'                           <h6 class="card-title"> Harum Quae Porro</h5>'.
'                           <p>Fuga quae ratione inventore Perferendis porro.</p>'.
'                           <a href="javascript:void(0)" class="small text-muted">Go To The Article</a>'.
'                       </div>'.
'                   </div>'.
'               </div>'.
'               <div class="col-md-4">'.
'                   <div class="card border-0 mb-4">'.
'                       <img src="assets/imgs/blog-3.jpg" alt="" class="card-img-top w-100">'.
'                       <div class="card-body">                         '.
'                           <h6 class="card-title">Qui optio neque alias</h6>'.
'                           <p>Fuga quae ratione inventore Perferendis porro.</p>'.
'                           <a href="javascript:void(0)" class="small text-muted">Go To The Article</a>'.
'                       </div>'.
'                   </div>'.
'               </div>'.
'           </div>'.
'       </div>'.
'   </section>'.
'   <!-- End of Blog Section -->'.
''.
'   <!-- Blog Section -->'.
'      <section class="section" id="Venue">'.
'          <div class="container">'.
'              <h6 class="section-title mb-0 text-center"> 오시는 길</h6>'.
'              <center><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d940.1644995595932!2d126.99210242343874!3d37.57099161434905!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x357ca326d682190b%3A0xa830a85713f74289!2zKOyjvCnsvIDsnbTsp4DslYTsnbTti7DrsYXtgaw!5e0!3m2!1sko!2skr!4v1680223810775!5m2!1sko!2skr" width="480" height="320" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe></center>'.
'   </div>'.
'      </section>'.
'    <!-- Contact Section -->'.
'   <section id="contact" class="section has-img-bg pb-0">'.
'       <div class="container">'.
'           <div class="row align-items-center">'.
'               <div class="col-md-5 my-3">'.
'                   <h6 class="mb-0">Phone</h6>'.
'                   <p class="mb-0">+82 010-8411-5758</p>'.
'                   <p class="mb-4">+82 010-2311-4103</p>'.
'                    <h6 class="mb-0">Address</h6>'.
'	    <p class="mb-0">서울시 종로구 돈화문로 26 KG-ITBANK 508호</p>'.
'                   <p class="mb-4">26, Donhwamun-ro, Jongno-gu, Seoul, KG-ITBANK 508</p>'.
'                    <h6 class="mb-0">Email</h6>'.
'                   <p class="mb-0">cerveza9977@gmail.com</p>'.
'                   <p class="mb-0">wowocccc@naver.com</p>'.
'                   <p></p>'.
'               </div>'.
'               <div class="col-md-7">'.
'                   <form method="POST" action="insert_data.php">'.
'                       <h4 class="mb-4">참가 사전등록</h4>'.
'                       <div class="form-row">'.
'                           <div class="form-group col-sm-4">'.
'                               <input type="text" class="form-control text-white rounded-0'.
'				 bg-transparent" name="name" placeholder="Name" required>'.
'                           </div>'.
'                           <div class="form-group col-sm-4">'.
'                               <input type="email" class="form-control text-white rounded-0'.
'				 bg-transparent" name="Email" placeholder="Email" required>'.
'                           </div>'.
'                           <div class="form-group col-sm-4">'.
'                               <input type="text" class="form-control text-white rounded-0'.
'				 bg-transparent" name="phone" placeholder="Phone" required>'.
'                           </div>'.
'                           <div class="form-group col-12">'.
'                               <input type="text" class="form-control text-white rounded-0'.
'				 bg-transparent" name="passcode" placeholder="Passcode" required>'.
'                            </div>'.
'                           <div class="form-group col-12 mb-0">'.
'                               <button type="submit" class="btn btn-primary rounded w-md mt-3">Send</button>'.
'                           </div>                          '.
'                       </div>                          '.
'                   </form>'.
'               </div>'.
'           </div>'.
'           <!-- Page Footer -->'.
'           <footer class="mt-5 py-4 border-top border-secondary">'.
'               <p class="mb-0 small">&copy; <script>document.write(new Date().getFullYear())</script>, LeadMark Created By <a href="https://www.devcrud.com" target="_blank">DevCrud.</a>  All rights reserved </p>     '.
'           </footer>'.
'           <!-- End of Page Footer -->  '.
'       </div>'.
'   </section>'.
''.
'<!-- core  -->'.
'   <script src="assets/vendors/jquery/jquery-3.4.1.js"></script>'.
'   <script src="assets/vendors/bootstrap/bootstrap.bundle.js"></script>'.
'    <!-- bootstrap 3 affix -->'.
'<script src="assets/vendors/bootstrap/bootstrap.affix.js"></script>'.
'    <!-- Isotope -->'.
'   <script src="assets/vendors/isotope/isotope.pkgd.js"></script>'.
'    <!-- LeadMark js -->'.
'   <script src="assets/js/leadmark.js"></script>'.
'</body>'.
'</html>';

 echo $string; 
?>
