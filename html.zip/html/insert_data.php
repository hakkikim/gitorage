<?php
$name = $_POST["name"];
$email = $_POST["Email"];
$phone = $_POST["phone"];
$passcode = $_POST["passcode"];

// passcode 필드 값이 "123"이 아닌 경우, 데이터 저장 거부
if ($passcode != "123") {
    echo "입력한 패스코드가 올바르지 않습니다.";
} else {
    // 데이터베이스 연결
        $servername = "10.0.1.37:3306";
        $username = "molang";
        $password = "molang";
        $dbname = "Molang";

#	$jb_conn = mysqli_connect( "10.0.1.121:3306", "molang", "molang", "Molang" );
#	$jb_sql = "INSERT INTO userlist ( name, email, phone, passcode) VALUES ( '$name', '$email', '$phone', '$passcode' );";
#	mysqli_query( $jb_conn, $jb_sql );


        $conn = new mysqli($servername, $username, $password, $dbname);

    // 쿼리 실행
        $sql = "INSERT INTO userlist (name, email, phone, passcode) VALUES (?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssss", $name, $email, $phone, $passcode);
        $stmt->execute();
	
        if ($stmt->execute()) {
    // 성공 메시지 출력
        	echo "<p>Data inserted successfully!</p>";
        } else {
    	// 오류 메시지 출력
        	echo "<p>Error: " . $stmt->error . "</p>";
    }
}
	// 자원 해제
#	$stmt->close();
#	$conn->close();


?>

<html>
<body>
	<p>
	</p>
	<button onclick="goBack()">메인으로 돌아가기</button>

	<script>
	function goBack() {
	  window.location.href = "http://ALB-1449326769.ap-northeast-2.elb.amazonaws.com";

	}	
	</script>
</html>


